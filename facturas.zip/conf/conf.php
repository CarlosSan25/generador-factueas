<?php

// Creamos los datos de conexion de la base de datos

define('_HOSTNAME_', 'localhost');
define('_DATABASE_', 'cav_facturas');
define('_DB_USER_', 'admin_facturas');
define('_DB_PASS_', 'Desj71~30');
define('_DB_PORT_', '3306');

?>